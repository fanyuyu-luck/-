<template>
	<view class="poster">
		<swiper circular skip-hidden-item-layout="true"  
		:previous-margin='previousMargin+"rpx"' 
		:next-margin='nextMargin+"rpx"' 
		class="card-swiper" 
		:indicator-dots="true" 
		@change="cardSwiper"  
		:duration="1000" 
		indicator-color="rgba(197, 197, 197, 1)" 
		indicator-active-color="rgba(255, 162, 0, 1)">
			<block v-for="(item,index) in posterList" :key="item.id">
				<swiper-item class="swiper-item">
					<view class="item" :class="cardCur == index ? 'swiperactive': ''">
						<image class="banner" :src="item.imageA" mode="widthFix" @click="handleClick(item)"></image>
					</view>
				</swiper-item>
			</block>
		</swiper>
	</view>

</template>

<script>
	export default{
		name:'fy-swiper',
		props:{
			posterList:{
				type: Array,
				default() {
				  return []
				}
			}
		},
		data(){
			return{
				cardCur: 0,
				previousMargin:0,
				nextMargin:0,
				scrollTop:0
				
			}
			
		},
		watch:{
			posterList(newVal) {
			  this.$nextTick(() => {
			    // this.getTabItemWidth()
				this.previousMargin = 90
				this.nextMargin = 90
			  })
			}
		},
		methods:{
			cardSwiper(e) {
			    this.cardCur = e.detail.current
			},
			handleClick(e){
				console.log(e)
				this.$emit('getItem',e)
			}
		}
	}
</script>

<style lang="scss" scoped>
		.poster{
			width: 100%;
			margin-top: 50rpx;
			.card-swiper{
				height:915rpx;
				.swiper-item{
						.item,.swiperactive{
							position: relative;
							display: block;
							height: 100%;
							transform: scale(0.93);
							transition: all .5s ease-in 0s;
							overflow: hidden;
							.banner{
								display: block;
								width: 95%;
								margin: 0 auto;
							}
							.box{
								position: absolute;
								top: 45%;
								left: 50%;
								transform: translate(-50%,-50%);
							}	
						}
						.swiperactive{
							transform: scale(1);
						}
					
				}
				
			}
		}
</style>
